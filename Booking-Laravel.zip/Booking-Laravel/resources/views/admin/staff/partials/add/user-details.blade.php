<div class="tab-pane fade show active" id="user-details" role="tabpanel">
    <div class="row">
        @include('admin.staff.partials.fields.add.avatar')
        </div>
</div>