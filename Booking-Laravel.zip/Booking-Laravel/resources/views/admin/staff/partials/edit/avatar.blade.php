<div class="tab-pane fade show active" id="user-details" role="tabpanel">
    <div class="row">

        {{-- Avatar --}}
        <div class="col-md-12 mb-3 text-center">
            <img src="{{ $staff->avatar ? asset('storage/' . $staff->avatar) : asset('assets/images/no-image-available.png') }}" class="img-radius mb-3 wid-80 hei-80" alt="User Avatar">
            <div class="custom-file mx-auto">
                <input type="file" class="custom-file-input" name="avatar" id="avatar" accept=".jpg,.jpeg,.png,.gif,image/jpeg,image/png,image/gif">
                <label class="custom-file-label" for="avatar">Choose file...</label>
            </div>
        </div>

        {{-- Name --}}
        <div class="col-md-6">
            <div class="form-group">
                <label>Name:</label>
                <input type="text" class="form-control" name="name" value="{{ old('name', $staff->name) }}" required>
            </div>
        </div>

        {{-- Email --}}
        <div class="col-md-6">
            <div class="form-group">
                <label>Email:</label>
                <input type="email" class="form-control" name="email" value="{{ old('email', $staff->email) }}" required>
            </div>
        </div>

        {{-- Password --}}
        <div class="col-md-6">
            <div class="form-group">
                <label>Password:</label>
                <input type="password" class="form-control" name="password" id="password" placeholder="Enter Password">
            </div>
        </div>

        {{-- Confirm Password --}}
        <div class="col-md-6">
            <div class="form-group">
                <label>Confirm Password:</label>
                <input type="password" class="form-control" name="password_confirmation" id="password_confirmation" placeholder="Confirm Password">
                <div id="password-error" class="text-danger mt-1 d-none">Passwords do not match.</div>
            </div>
        </div>

        {{-- Phone Number --}}
        <div class="col-md-6">
            <div class="form-group">
                <label class="form-label">Phone Number</label>
                <div class="input-group">
                    <select class="form-control" name="code" style="max-width: 100px;">
                        @foreach($phoneCountries as $country)
                        <option value="{{ $country['code'] }}"
                            @if(
                            (!old('phone_code', $staff->phone_code ?? null) && $country['code'] == '+91') ||
                            (old('phone_code', $staff->phone_code ?? null) == $country['code'])
                            )
                            selected
                            @endif
                            >
                            {{ $country['code'] }}
                        </option>
                        @endforeach
                    </select>

                    <input type="text" class="form-control" name="phone_number"
                        value="{{ old('phone_number', $staff->phone_number ?? '') }}" required>
                </div>
                @error('phone_number')
                <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>
        </div>

        @if($roles)
        <div class="col-md-6 d-none">
            <div class="form-group">
                <label>Role:</label>
                <select class="form-control select-user" name="role" required>
                    <option value="{{ $roles->id }}" selected>{{ $roles->name }}</option>
                </select>
            </div>
        </div>
        @endif
        {{-- Status --}}
        <div class="col-md-6">
            <div class="form-group">
                <label for="status" class="form-label d-block">Status</label>
                <select name="status" id="status" class="form-control select-user">
                    <option value="{{ config('constants.status.active') }}"
                        {{ old('status', $staff->status) == config('constants.status.active') ? 'selected' : '' }}>
                        Active
                    </option>
                    <option value="{{ config('constants.status.inactive') }}"
                        {{ old('status', $staff->status) == config('constants.status.inactive') ? 'selected' : '' }}>
                        Inactive
                    </option>
                </select>
                @error('status')
                <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>
        </div>

    </div>
</div>