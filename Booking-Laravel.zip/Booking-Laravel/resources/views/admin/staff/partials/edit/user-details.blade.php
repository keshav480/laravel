<div class="tab-pane fade show active" id="user-details" role="tabpanel">
        @include('admin.staff.partials.edit.avatar')
</div>