<?php $__env->startSection('content'); ?>
<section class="pcoded-main-container">
    <div class="pcoded-content">
        <!-- [ Main Content ] start -->
        <div class="row">
            <!-- [ Booking Validation ] start -->
            <div class="col-sm-12">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-header">
                            <div class="page-block">
                                <div class="row align-items-center">
                                    <div class="col-md-12">
                                        <div class="page-header-title">
                                            <h5 class="m-b-10">Add Booking</h5>
                                        </div>
                                        <ul class="breadcrumb">
                                            <li class="breadcrumb-item"><i class="feather icon-home"></i></li>
                                            <li class="breadcrumb-item"><a href="<?php echo e(route('booking.list')); ?>">Bookings</a></li>
                                            <li class="breadcrumb-item"><a href="">Add Booking</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header">
                                <h5>Add Booking</h5>
                            </div>
                            <div class="card-body">
                                <form action="<?php echo e(route('booking.save')); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="card-body">
                                            <div class="modal fade" id="bookingTemplateModal" tabindex="-1" aria-labelledby="bookingTemplateModalLabel" aria-hidden="true">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="bookingTemplateModalLabel">Select Booking Template</h5>
                                                        </div>

                                                        <div class="modal-body">
                                                            <select class="form-control" id="bookingTemplateselect">
                                                                <option value="">Select a template</option>
                                                                <?php $__currentLoopData = $alltemplates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($template->data); ?>" data-id="<?php echo e($template->id); ?>">
                                                                    <?php echo e($template->template_name); ?>

                                                                </option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <a href="<?php echo e(route('booking.list')); ?>" class="btn btn-secondary">Back</a>
                                                            <button type="button" id="loadTemplateBtn" class="btn btn-primary">Load Template</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <!-- Booking Form -->
                                            <form action="<?php echo e(route('booking.save')); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <div id="dynamictemplateFields"></div>
                                                <input type="hidden" name="booking_template_id" id="bookingTemplateId">
                                                <input type="hidden" name="booking_data" id="bookingData">
                                                <input type="hidden" name="customer_id" id="customer_id" value="<?php echo e(Auth::id()); ?>">
                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <div class="form-group mt-3">
                                                            <label>Staff List</label>
                                                            <select class="form-control selected_staff" name="selected_staff">
                                                                <option value="">Select Staff</option>
                                                                <?php $__currentLoopData = $alluser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($user->name); ?>" data-customer_id="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                            <?php $__errorArgs = ['selected_staff'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="error"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="form-group mt-3">
                                                            <label>Booking Date/Time</label>
                                                            <input type="datetime-local" id="booking_datetime" name="booking_datetime" class="form-control">
                                                            <?php $__errorArgs = ['booking_datetime'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                            <div class="text-danger"><?php echo e($message); ?></div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <button type="submit" class="btn btn-primary">Submit</button>
                                            </form>
                                        </div>
                                    </div>
                            </div>
                            <!-- [ Booking Validation ] end -->
                        </div>
                        <!-- [ Main Content ] end -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Booking-Laravel/resources/views/admin/booking/add.blade.php ENDPATH**/ ?>