<?php $__env->startSection('content'); ?>
<div class="pcoded-main-container">
    <div class="pcoded-content">
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-12">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Edit Staff</h5>
                        </div>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><i class="feather icon-home"></i></a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('staff.list')); ?>">Staff</a></li>
                            <li class="breadcrumb-item">Edit Staff</li>
                        </ul>
                    </div>
                </div>
            </div>

            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    
                    <div class="card-body">
                        <ul class="nav nav-tabs mb-3" role="tablist">
                            <li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#user-details" role="tab"><i class="feather icon-info"></i> User Details</a></li>
                            <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#assigned-services" role="tab"><i class="feather icon-briefcase"></i> Assigned Services</a></li>
                            <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#working-days" role="tab"><i class="feather icon-clock"></i> Work Hours</a></li>
                            <li class="nav-item"><a class="nav-link" data-toggle="tab" href="#days-off" role="tab"><i class="feather icon-calendar"></i> Days Off</a></li>
                        </ul>

                        <form method="POST" action="<?php echo e(route('staff.update', $staff->id)); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <div class="tab-content">

                                
                                <?php echo $__env->make('admin.staff.partials.edit.user-details', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                
                                <?php echo $__env->make('admin.staff.partials.edit.assigned-services', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                
                                <?php echo $__env->make('admin.staff.partials.edit.working-days', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                
                                <?php echo $__env->make('admin.staff.partials.edit.days-off', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                <div class="mt-4">
                                    <button type="submit" class="btn btn-primary savebutton">Update</button>
                                    <a href="<?php echo e(route('staff.list')); ?>" class="btn btn-secondary">Back</a>
                                </div>

                        </form>
                    </div> 
                </div> 
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Booking-Laravel/resources/views/admin/staff/edit.blade.php ENDPATH**/ ?>