<div class="tab-pane fade" id="assigned-services" role="tabpanel">
    <button type="button" id="addServicesBtn" class="btn btn-sm btn-primary mb-3" data-toggle="modal" data-target="#servicesModal">
        <i class="feather icon-plus"></i> Add Services
    </button>

    <div class="table-responsive">
        <table class="table table-hover mb-0" id="servicesTable">
            <thead class="bg-light">
                <tr>
                    <th class="text-left">Service</th>
                    <th class="text-center">Price</th>
                    <th class="text-center">Remove</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $assignedServices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr data-id="<?php echo e($service->id); ?>">
                        <td>
                            <input type="hidden" name="assigned_services[<?php echo e($service->id); ?>][id]" value="<?php echo e($service->id); ?>">
                            <?php echo e($service->name); ?>

                        </td>
                        <td class="text-center">
                            <input type="text" name="assigned_services[<?php echo e($service->id); ?>][price]"
                                class="form-control form-control-sm text-center"
                                value="$<?php echo e(number_format($service->price, 2)); ?>" readonly>
                        </td>
                        <td class="text-center">
                            <button type="button" class="btn btn-sm btn-danger remove-service">REMOVE</button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr id="noServiceRow">
                        <td colspan="3" class="text-center text-muted">No services assigned yet.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php echo $__env->make('admin.staff.partials.modals.services', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Booking-Laravel/resources/views/admin/staff/partials/edit/assigned-services.blade.php ENDPATH**/ ?>