<div class="tab-pane fade show active" id="user-details" role="tabpanel">
    <div class="row">
        <?php echo $__env->make('admin.staff.partials.fields.add.avatar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
</div><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Booking-Laravel/resources/views/admin/staff/partials/add/user-details.blade.php ENDPATH**/ ?>