<?php $__env->startSection('content'); ?>
<div class="pcoded-main-container">
    <div class="pcoded-content">
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-12">
                        <div class="page-header-title">
                            <h5>Add Category</h5>
                        </div>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(route('dashboard')); ?>">
                                    <i class="feather icon-home"></i>
                                </a>
                            </li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('category.list')); ?>">Categories</a></li>
                            <li class="breadcrumb-item">Add Category</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

          <form action="<?php echo e(route('category.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
                <!-- Left Column -->
                <div class="col-md-7 order-md-1">
                    <div class="card">
                        <div class="card-header">
                            <h5>Category Details</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <!-- Name -->
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label class="form-label">Category Name</label>
                                        <input
                                        type="text"
                                        name="category_name"
                                        id="category_name"
                                        class="form-control <?php $__errorArgs = ['category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        placeholder="Enter category name"
                                        value="<?php echo e(old('category_name')); ?>"
                                        required>
                                    <?php $__errorArgs = ['category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback d-block" id="categoryNameError" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Right Column - Original Avatar Upload -->
                <div class="col-md-5 order-md-2">
                    <div class="card">
                        <div class="card-header">
                            <h5>Settings</h5>
                        </div>
                        <div class="card-body">
                            <div class="form-group col-md-12 p-0">
                          <!-- Status -->
                                <div class="form-group mt-3">
                                <label for="status" class="form-label d-block">Status</label>
                                <select name="status" id="status" class="form-control select-user">
                                    <option value="<?php echo e(config('constants.status.active')); ?>"
                                        <?php echo e(old('status', config('constants.status.active')) == config('constants.status.active') ? 'selected' : ''); ?>>
                                        Active
                                    </option>
                                    <option value="<?php echo e(config('constants.status.inactive')); ?>"
                                        <?php echo e(old('status') == config('constants.status.inactive') ? 'selected' : ''); ?>>
                                        Inactive
                                    </option>
                                </select>
                                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                                
                               <label class="form-label">Featured image</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">Upload</span>
                                </div>
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" name="thumbnail" id="thumbnail"
                                        accept=".jpg,.jpeg,.png,.gif,image/jpeg,image/png,image/gif">
                                    <label class="custom-file-label" for="thumbnail">Choose file...</label>
                                </div>
                            </div>
                            <small class="form-text text-muted">
                                Supported image types: JPG, JPEG, PNG, or GIF.
                            </small>
                            <div id="image-preview-container" class="row d-none mt-3">
                                <div class="col-md-3 position-relative">
                                    <div class="card shadow-sm">
                                        <img id="image-preview" class="card-img-top img-thumbnail" alt="Image Preview">

                                        
                                        <button type="button"
                                            id="remove-preview"
                                            class="btn btn-sm btn-dark text-white position-absolute top-0 end-0 m-1 rounded-pill delete-existing-image"
                                            title="Remove image">
                                            &times;
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <?php $__errorArgs = ['thumbnail'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="error text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="row mt-4">
                            <div class="col-md-12 text-right">
                                <button type="submit" class="btn btn-primary">Save</button>
                                <a href="<?php echo e(route('category.list')); ?>" class="btn btn-secondary ml-2">Back</a>
                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Booking-Laravel/resources/views/admin/category/add.blade.php ENDPATH**/ ?>