<header class="navbar pcoded-header navbar-expand-lg navbar-light headerpos-fixed">

    <div class="m-header">
        <a class="mobile-menu" id="mobile-collapse" href="#!"><span></span></a>
        <a href="#!" class="b-brand">
            <!-- ======== change your logo here ============ -->
        </a>
        <a href="#!" class="mob-toggler">
            <i class="feather icon-more-vertical"></i>
        </a>
    </div>

    <div class="collapse navbar-collapse">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a href="#!" class="pop-search"><i class="feather icon-search"></i></a>
                <div class="search-bar">
                    <input type="text" class="form-control border-0 shadow-none" placeholder="search here">
                    <button type="button" class="close" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            </li>

            <!-- Dropdown -->
            <li class="nav-item">
                <div class="dropdown">
                    <a class="dropdown-toggle h-drop" href="#" data-toggle="dropdown">
                        Dropdown
                    </a>
                    <div class="dropdown-menu profile-notification">
                        <ul class="pro-body">
                            <li><a href="<?php echo e(route('user.edit', Auth::id())); ?>" class="dropdown-item"><i class="fas fa-circle"></i> Profile</a></li>
                            <li><a href="email_inbox.html" class="dropdown-item"><i class="fas fa-circle"></i> My Messages</a></li>
                            <li><a href="auth-signin.html" class="dropdown-item"><i class="fas fa-circle"></i> Lock Screen</a></li>
                        </ul>
                    </div>
                </div>
            </li>

            <!-- Mega menu -->
            <li class="nav-item">
                <div class="dropdown mega-menu">
                    <a class="dropdown-toggle h-drop" href="#" data-toggle="dropdown">
                        Mega
                    </a>
                    <div class="dropdown-menu profile-notification">
                        <div class="row no-gutters">
                            <!-- UI Element -->
                            <div class="col">
                                <h6 class="mega-title">UI Element</h6>
                                <ul class="pro-body">
                                    <li><a href="#!" class="dropdown-item"><i class="fas fa-circle"></i> Alert</a></li>
                                    <li><a href="#!" class="dropdown-item"><i class="fas fa-circle"></i> Button</a></li>
                                    <li><a href="#!" class="dropdown-item"><i class="fas fa-circle"></i> Badges</a></li>
                                    <li><a href="#!" class="dropdown-item"><i class="fas fa-circle"></i> Cards</a></li>
                                    <li><a href="#!" class="dropdown-item"><i class="fas fa-circle"></i> Modal</a></li>
                                    <li><a href="#!" class="dropdown-item"><i class="fas fa-circle"></i> Tabs & pills</a></li>
                                </ul>
                            </div>
                            <!-- Forms -->
                            <div class="col">
                                <h6 class="mega-title">Forms</h6>
                                <ul class="pro-body">
                                    <li><a href="#!" class="dropdown-item"><i class="feather icon-minus"></i> Elements</a></li>
                                    <li><a href="#!" class="dropdown-item"><i class="feather icon-minus"></i> Validation</a></li>
                                    <li><a href="#!" class="dropdown-item"><i class="feather icon-minus"></i> Masking</a></li>
                                    <li><a href="#!" class="dropdown-item"><i class="feather icon-minus"></i> Wizard</a></li>
                                    <li><a href="#!" class="dropdown-item"><i class="feather icon-minus"></i> Picker</a></li>
                                    <li><a href="#!" class="dropdown-item"><i class="feather icon-minus"></i> Select</a></li>
                                </ul>
                            </div>
                            <!-- Application -->
                            <div class="col">
                                <h6 class="mega-title">Application</h6>
                                <ul class="pro-body">
                                    <li><a href="#!" class="dropdown-item"><i class="feather icon-mail"></i> Email</a></li>
                                    <li><a href="#!" class="dropdown-item"><i class="feather icon-clipboard"></i> Task</a></li>
                                    <li><a href="#!" class="dropdown-item"><i class="feather icon-check-square"></i> To-Do</a></li>
                                    <li><a href="#!" class="dropdown-item"><i class="feather icon-image"></i> Gallery</a></li>
                                    <li><a href="#!" class="dropdown-item"><i class="feather icon-help-circle"></i> Helpdesk</a></li>
                                </ul>
                            </div>
                            <!-- Extension -->
                            <div class="col">
                                <h6 class="mega-title">Extension</h6>
                                <ul class="pro-body">
                                    <li><a href="#!" class="dropdown-item"><i class="feather icon-file-plus"></i> Editor</a></li>
                                    <li><a href="#!" class="dropdown-item"><i class="feather icon-file-minus"></i> Invoice</a></li>
                                    <li><a href="#!" class="dropdown-item"><i class="feather icon-calendar"></i> Full calendar</a></li>
                                    <li><a href="#!" class="dropdown-item"><i class="feather icon-upload-cloud"></i> File upload</a></li>
                                    <li><a href="#!" class="dropdown-item"><i class="feather icon-scissors"></i> Image cropper</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </li>
        </ul>

        <!-- Right side -->
        <ul class="navbar-nav ml-auto">
            <li>
                <div class="dropdown drp-user">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                        <i class="feather icon-user"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right profile-notification">
                        <div class="pro-head">
                            <img src="<?php echo e(Auth::user()->avatar ? Storage::url(Auth::user()->avatar) : asset('assets/images/no-image-available.png')); ?>" class="img-radius hei-40" alt="User-Profile-Image">
                            <span><?php echo e(Auth::user()->name); ?></span>
                        </div>
                        <ul class="pro-body">
                            <li>
                                <a href="<?php echo e(route('profile')); ?>" class="dropdown-item">
                                    <i class="feather icon-user"></i> Profile
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('logout')); ?>" class="dropdown-item">
                                    <i class="feather icon-power"></i> Logout
                                </a>
                            </li>

                            <!-- Switch Back Button -->
                            <?php
                                $isImpersonating = session()->has('impersonate_original_user') || Cookie::get('impersonate_original_user');
                                $loginUser = null;
                                if ($isImpersonating) {
                                    $loginUser = \App\Models\User::find(session('impersonate_original_user') ?? Cookie::get('impersonate_original_user'));
                                }
                            ?>

                            <?php if($isImpersonating && $loginUser): ?>
                            <li>
                                <form method="POST" action="<?php echo e(route('user.switch.back')); ?>" style="margin: 0;">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="dropdown-item d-flex align-items-center submit-user">
                                        <i class="feather icon-log-out"></i>
                                        Switch Back to <?php echo e($loginUser->name); ?>

                                    </button>
                                </form>
                            </li>
                            <?php endif; ?>

                        </ul>
                    </div>
                </div>
            </li>
        </ul>
    </div>
</header>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Booking-Laravel/resources/views/admin/layouts/header.blade.php ENDPATH**/ ?>