<nav class="pcoded-navbar menupos-fixed <?php if($isNavCollapsed ?? false): ?> navbar-collapsed <?php endif; ?>">
    <div class="navbar-wrapper d-flex flex-column" style="height: 92vh;">
        <div class="navbar-content scroll-div flex-grow-1 d-flex flex-column">

            
            <div>
                <div class="main-menu-header">
                    <img class="img-radius hei-40"
                         src="<?php echo e(Auth::user()->avatar ? Storage::url(Auth::user()->avatar) : asset('assets/images/no-image-available.png')); ?>"
                         alt="User-Profile-Image">
                    <div class="user-details">
                        <div id="more-details">
                            <span class="mb-0 font-weight-bold">
                                <?php echo e(Auth::user()->name); ?>

                                <i class="fa fa-chevron-down m-l-5"></i>
                            </span>
                        </div>
                    </div>
                </div>

                <div class="collapse" id="nav-user-link">
                    <ul class="list-inline">
                        <li class="list-inline-item">
                            <a href="<?php echo e(route('profile')); ?>" data-toggle="tooltip" title="Profile">
                                <i class="feather icon-user"></i>
                            </a>
                        </li>
                        <li class="list-inline-item">
                            <a href="<?php echo e(route('logout')); ?>" data-toggle="tooltip" title="Logout" class="text-danger">
                                <i class="feather icon-power"></i>
                            </a>
                        </li>
                    </ul>
                </div>

                
                <ul class="nav pcoded-inner-navbar">

                    
                    <li class="nav-item">
                        <a href="<?php echo e(route('dashboard')); ?>" class="nav-link <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
                            <span class="pcoded-micon"><i class="feather icon-home"></i></span>
                            <span class="pcoded-mtext">Dashboard</span>
                        </a>
                    </li>

                    
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view users', 'create users', 'edit users', 'delete users'])): ?>
                        <li class="nav-item pcoded-hasmenu <?php echo e(request()->routeIs('user.*') ? 'pcoded-trigger' : ''); ?>">
                            <a href="#!" class="nav-link">
                                <span class="pcoded-micon"><i class="feather icon-users"></i></span>
                                <span class="pcoded-mtext">Users</span>
                            </a>
                            <ul class="pcoded-submenu" <?php if(request()->routeIs('user.*')): ?> style="display:block;" <?php endif; ?>>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create users')): ?>
                                    <li class="<?php echo e(request()->routeIs('user.add') ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('user.add')); ?>">Add User</a>
                                    </li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view users')): ?>
                                    <li class="<?php echo e(request()->routeIs('user.list') ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('user.list')); ?>">All Users</a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>

                    
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view roles', 'create roles', 'edit roles', 'delete roles'])): ?>
                        <li class="nav-item pcoded-hasmenu <?php echo e(request()->routeIs('roles.*') ? 'pcoded-trigger' : ''); ?>">
                            <a href="#!" class="nav-link">
                                <span class="pcoded-micon"><i class="fas fa-shield-alt"></i></span>
                                <span class="pcoded-mtext">Manage Roles</span>
                            </a>
                            <ul class="pcoded-submenu" <?php if(request()->routeIs('roles.*')): ?> style="display:block;" <?php endif; ?>>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create roles')): ?>
                                    <li class="<?php echo e(request()->routeIs('roles.add') ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('roles.add')); ?>">Add Role</a>
                                    </li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view roles')): ?>
                                    <li class="<?php echo e(request()->routeIs('roles.list') ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('roles.list')); ?>">All Roles</a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>

                    
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view templates', 'create templates', 'edit templates', 'delete templates'])): ?>
                        <li class="nav-item pcoded-hasmenu <?php echo e(request()->routeIs('template.*') ? 'pcoded-trigger' : ''); ?>">
                            <a href="#!" class="nav-link">
                                <span class="pcoded-micon"><i class="feather icon-file-text"></i></span>
                                <span class="pcoded-mtext">Booking Templates</span>
                            </a>
                            <ul class="pcoded-submenu" <?php if(request()->routeIs('template.*')): ?> style="display:block;" <?php endif; ?>>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create templates')): ?>
                                    <li class="<?php echo e(request()->routeIs('template.add') ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('template.add')); ?>">Add Booking Template</a>
                                    </li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view templates')): ?>
                                    <li class="<?php echo e(request()->routeIs('template.list') ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('template.list')); ?>">All Booking Templates</a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>

                    
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view services', 'create services', 'edit services', 'delete services'])): ?>
                        <li class="nav-item pcoded-hasmenu <?php echo e(request()->routeIs('service.*') ? 'pcoded-trigger' : ''); ?>">
                            <a href="#!" class="nav-link">
                                <span class="pcoded-micon"><i class="fas fa-tools"></i></span>
                                <span class="pcoded-mtext">Manage Services</span>
                            </a>
                            <ul class="pcoded-submenu" <?php if(request()->routeIs('service.*')): ?> style="display:block;" <?php endif; ?>>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create services')): ?>
                                    <li class="<?php echo e(request()->routeIs('service.add') ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('service.add')); ?>">Add Service</a>
                                    </li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view services')): ?>
                                    <li class="<?php echo e(request()->routeIs('service.list') ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('service.list')); ?>">All Services</a>
                                    </li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view categories')): ?>
                                    <li class="<?php echo e(request()->routeIs('category.list') ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('category.list')); ?>">Categories</a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>

                    
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view staffs', 'create staffs', 'edit staffs', 'delete staffs'])): ?>
                        <li class="nav-item pcoded-hasmenu <?php echo e(request()->routeIs('staff.*') ? 'pcoded-trigger' : ''); ?>">
                            <a href="#!" class="nav-link">
                                <span class="pcoded-micon"><i class="fas fa-user-tie"></i></span>
                                <span class="pcoded-mtext">Manage Staffs</span>
                            </a>
                            <ul class="pcoded-submenu" <?php if(request()->routeIs('staff.*')): ?> style="display:block;" <?php endif; ?>>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create staffs')): ?>
                                    <li class="<?php echo e(request()->routeIs('staff.create') ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('staff.create')); ?>">Add Staff</a>
                                    </li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view staffs')): ?>
                                    <li class="<?php echo e(request()->routeIs('staff.list') ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('staff.list')); ?>">All Staffs</a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>

                    
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view bookings', 'create bookings', 'edit bookings', 'delete bookings'])): ?>
                        <li class="nav-item pcoded-hasmenu <?php echo e(request()->routeIs('booking.*') ? 'pcoded-trigger' : ''); ?>">
                            <a href="#!" class="nav-link">
                                <span class="pcoded-micon"><i class="feather icon-book"></i></span>
                                <span class="pcoded-mtext">Bookings</span>
                            </a>
                            <ul class="pcoded-submenu" <?php if(request()->routeIs('booking.*')): ?> style="display:block;" <?php endif; ?>>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create bookings')): ?>
                                    <li class="<?php echo e(request()->routeIs('booking.add') ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('booking.add')); ?>">Add Booking</a>
                                    </li>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view bookings')): ?>
                                    <li class="<?php echo e(request()->routeIs('booking.list') ? 'active' : ''); ?>">
                                        <a href="<?php echo e(route('booking.list')); ?>">All Bookings</a>
                                    </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>

                </ul>
            </div>

            
            <?php
                $isImpersonating = session()->has('impersonate_original_user') || Cookie::get('impersonate_original_user');
            ?>

            <?php if($isImpersonating && Auth::user() && isset($loginUser)): ?>
                <div class="mt-auto">
                    <form method="POST" action="<?php echo e(route('user.switch.back')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger btn-block d-flex align-items-center navbar-switch-button">
                            <i class="feather icon-log-out"></i>
                            <span class="ml-2">Switch Back</span>
                        </button>
                    </form>
                </div>
            <?php endif; ?>
        </div>
    </div>
</nav>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Booking-Laravel/resources/views/admin/layouts/navbar.blade.php ENDPATH**/ ?>