<?php $__env->startSection('content'); ?>
<div class="pcoded-main-container">
	<div class="pcoded-content">
		<div class="page-header">
			<div class="page-block">
				<div class="row align-items-center">
					<div class="col-md-10">
						<div class="page-header-title">
							<h5>All Bookings</h5>
						</div>
						<ul class="breadcrumb">
							<li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><i class="feather icon-home"></i></a></li>
							<li class="breadcrumb-item"><a href="<?php echo e(route('booking.list')); ?>">Booking</a></li>
							<li class="breadcrumb-item"><a href="<?php echo e(route('booking.list')); ?>">All Bookings</a></li>
						</ul>
					</div>
					<div class="col-md-2">
						<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create bookings')): ?>
						<a href="<?php echo e(route('booking.add')); ?>" class="btn btn-primary float-right p-2">Add Booking</a>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>

		<div class="row">
			<div class="col-lg-12">
				<div class="card user-profile-list">
					<div class="card-body">
						<div class="dt-responsive table-responsive">
							<table id="booking-list-table" class="table nowrap" width="100%">
								<thead>
									<tr>
										<th style="display:none;">ID</th> 
										<th>Template Name</th>
										<th>Booked By</th>
										<th>Created Date</th>
										<th>Status</th>
										<th>Actions</th>
									</tr>
								</thead>
								<tbody></tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<script>
	$(function() {
		$('#booking-list-table').DataTable({
			processing: true,
			serverSide: true,
			ajax: "<?php echo e(route('booking.list')); ?>",
			columns: [{
					data: 'id',
					name: 'id',
					visible: false
				}, 
				{
					data: 'template_name',
					name: 'template_name'
				},
				{
					data: 'booked_by',
					name: 'booked_by'
				},
				{
					data: 'created_at',
					name: 'created_at'
				},
				{
					data: 'status',
					name: 'status',
					orderable: false,
					searchable: false
				},
				{
					data: 'action',
					name: 'action',
					orderable: false,
					searchable: false
				}
			],
			order: [
				[3, 'desc']
			],
			lengthMenu: [
				[10, 25, 50, 100],
				[10, 25, 50, 100]
			],
		});
		toastr.options = {
			"closeButton": true,
			"progressBar": true,
			"timeOut": "4000",
			"positionClass": "toast-top-right"
		};

		<?php if(session('success')): ?>
		toastr.success("<?php echo e(session('success')); ?>");
		<?php endif; ?>

		<?php if(session('error')): ?>
		toastr.error("<?php echo e(session('error')); ?>");
		<?php endif; ?>

		<?php if(session('info')): ?>
		toastr.info("<?php echo e(session('info')); ?>");
		<?php endif; ?>

		<?php if(session('warning')): ?>
		toastr.warning("<?php echo e(session('warning')); ?>");
		<?php endif; ?>
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Booking-Laravel/resources/views/admin/booking/index.blade.php ENDPATH**/ ?>