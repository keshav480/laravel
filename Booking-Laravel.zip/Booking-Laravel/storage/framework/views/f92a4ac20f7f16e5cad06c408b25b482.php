    

    <?php $__env->startSection('content'); ?>
    <section class="pcoded-main-container">
        <div class="pcoded-content">
            <div class="page-header">
                <div class="page-block">
                    <div class="row align-items-center">
                        <div class="col-md-12">
                            <div class="page-header-title">
                                <h5 class="m-b-10">Edit Booking</h5>
                            </div>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="<?php echo e(route('dashboard')); ?>">
                                        <i class="feather icon-home"></i>
                                    </a>
                                </li>
                                <li class="breadcrumb-item">
                                    <a href="<?php echo e(route('booking.list')); ?>">Bookings</a>
                                </li>
                                <li class="breadcrumb-item">Edit Booking</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <form action="<?php echo e(route('booking.update', $booking->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="row">
                    <div class="col-md-12 order-md-2">
                        <div class="card">
                            <div class="card-header">
                                <h5>Edit Booking</h5>
                            </div>

                            <div class="card-body">
                                
                                <?php if(session('success')): ?>
                                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                                <?php endif; ?>
                                <?php if(session('error')): ?>
                                <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
                                <?php endif; ?>

                                <h5 class="mb-4">Booking Information</h5>

                                
                                <?php echo $dynamicFieldHtml; ?>


                                <div class="row">
                                    
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label">Staff</label>
                                            <select class="form-control" name="staff" required>
                                                <option value="">Select Staff</option>
                                                <?php $__currentLoopData = $staffList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($staff->id); ?>"
                                                    <?php echo e(old('staff', $booking->selected_staff) == $staff->id ? 'selected' : ''); ?>>
                                                    <?php echo e($staff->name); ?>

                                                </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    
                                    <div class="col-md-4">
                                        <div class="form-group">
                                            <label class="form-label">Booking Date and Time</label>
                                            <input
                                                type="datetime-local"
                                                class="form-control"
                                                name="booking_datetime"
                                                value="<?php echo e(old('booking_datetime', $booking->booking_datetime)); ?>"
                                                required>
                                        </div>
                                    </div>
                                </div>

                                
                                <button type="submit" class="btn btn-primary">Update</button>
                                <a href="<?php echo e(route('booking.list')); ?>" class="btn btn-secondary ml-2">Back</a>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </section>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Booking-Laravel/resources/views/admin/booking/edit.blade.php ENDPATH**/ ?>