<div class="tab-pane fade show active" id="user-details" role="tabpanel">
    <div class="row">

        
        <div class="col-md-12 mb-3 text-center">
            <img src="<?php echo e($staff->avatar ? asset('storage/' . $staff->avatar) : asset('assets/images/no-image-available.png')); ?>" class="img-radius mb-3 wid-80 hei-80" alt="User Avatar">
            <div class="custom-file mx-auto">
                <input type="file" class="custom-file-input" name="avatar" id="avatar" accept=".jpg,.jpeg,.png,.gif,image/jpeg,image/png,image/gif">
                <label class="custom-file-label" for="avatar">Choose file...</label>
            </div>
        </div>

        
        <div class="col-md-6">
            <div class="form-group">
                <label>Name:</label>
                <input type="text" class="form-control" name="name" value="<?php echo e(old('name', $staff->name)); ?>" required>
            </div>
        </div>

        
        <div class="col-md-6">
            <div class="form-group">
                <label>Email:</label>
                <input type="email" class="form-control" name="email" value="<?php echo e(old('email', $staff->email)); ?>" required>
            </div>
        </div>

        
        <div class="col-md-6">
            <div class="form-group">
                <label>Password:</label>
                <input type="password" class="form-control" name="password" id="password" placeholder="Enter Password">
            </div>
        </div>

        
        <div class="col-md-6">
            <div class="form-group">
                <label>Confirm Password:</label>
                <input type="password" class="form-control" name="password_confirmation" id="password_confirmation" placeholder="Confirm Password">
                <div id="password-error" class="text-danger mt-1 d-none">Passwords do not match.</div>
            </div>
        </div>

        
        <div class="col-md-6">
            <div class="form-group">
                <label class="form-label">Phone Number</label>
                <div class="input-group">
                    <select class="form-control" name="code" style="max-width: 100px;">
                        <?php $__currentLoopData = $phoneCountries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($country['code']); ?>"
                            <?php if(
                            (!old('phone_code', $staff->phone_code ?? null) && $country['code'] == '+91') ||
                            (old('phone_code', $staff->phone_code ?? null) == $country['code'])
                            ): ?>
                            selected
                            <?php endif; ?>
                            >
                            <?php echo e($country['code']); ?>

                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <input type="text" class="form-control" name="phone_number"
                        value="<?php echo e(old('phone_number', $staff->phone_number ?? '')); ?>" required>
                </div>
                <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <?php if($roles): ?>
        <div class="col-md-6 d-none">
            <div class="form-group">
                <label>Role:</label>
                <select class="form-control select-user" name="role" required>
                    <option value="<?php echo e($roles->id); ?>" selected><?php echo e($roles->name); ?></option>
                </select>
            </div>
        </div>
        <?php endif; ?>
        
        <div class="col-md-6">
            <div class="form-group">
                <label for="status" class="form-label d-block">Status</label>
                <select name="status" id="status" class="form-control select-user">
                    <option value="<?php echo e(config('constants.status.active')); ?>"
                        <?php echo e(old('status', $staff->status) == config('constants.status.active') ? 'selected' : ''); ?>>
                        Active
                    </option>
                    <option value="<?php echo e(config('constants.status.inactive')); ?>"
                        <?php echo e(old('status', $staff->status) == config('constants.status.inactive') ? 'selected' : ''); ?>>
                        Inactive
                    </option>
                </select>
                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

    </div>
</div><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Booking-Laravel/resources/views/admin/staff/partials/edit/avatar.blade.php ENDPATH**/ ?>