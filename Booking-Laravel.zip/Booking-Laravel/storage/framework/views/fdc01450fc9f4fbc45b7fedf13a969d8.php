<?php
    $daySlug = Str::slug($day);
    $collapseId = 'collapse' . ucfirst($daySlug);
    $headingId = 'heading' . ucfirst($daySlug);
    $isFirst = $loop->first;
?>

<div class="card mb-1 border">
    <div class="d-flex justify-content-between align-items-center border-bottom px-3 py-2" id="<?php echo e($headingId); ?>">
        <div class="d-flex flex-grow-1 align-items-center justify-content-between">
            <span class="font-weight-bold"><?php echo e($day); ?></span>

            <div class="ml-auto d-flex align-items-center">
                <?php if($day === 'Monday'): ?>
                    <div class="custom-control custom-checkbox">
                        <input type="checkbox" class="custom-control-input apply-to-all-days"
                               id="applyAllDaysCheckbox" name= "apply_all_days" data-day="<?php echo e($daySlug); ?>">
                        <label class="custom-control-label ml-1 mb-0 medium" for="applyAllDaysCheckbox">
                            Apply to all days
                        </label>
                    </div>
                <?php endif; ?>

                <div class="chevron-toggle ml-3"
                     style="cursor:pointer;"
                     data-toggle="collapse"
                     data-target="#<?php echo e($collapseId); ?>"
                     data-parent="#workingHoursAccordion"
                     aria-expanded="<?php echo e($isFirst ? 'true' : 'false'); ?>"
                     aria-controls="<?php echo e($collapseId); ?>">
                    <i class="feather <?php echo e($isFirst ? 'icon-chevron-up' : 'icon-chevron-down'); ?>"></i>
                </div>
            </div>
        </div>
    </div>

    <div id="<?php echo e($collapseId); ?>"
         class="collapse <?php echo e($isFirst ? 'show' : ''); ?>"
         aria-labelledby="<?php echo e($headingId); ?>"
         data-parent="#workingHoursAccordion">
        <div class="card-body pt-2 pb-2 px-3">
            <div class="d-flex">
                
                <select class="form-control form-control-sm w-auto start-time select-user"
                        name="working_days[<?php echo e($daySlug); ?>][start]">
                    <?php for($h = 0; $h < 24; $h++): ?>
                        <?php $__currentLoopData = ['00', '30']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $time = str_pad($h, 2, '0', STR_PAD_LEFT) . ':' . $m; ?>
                            <option value="<?php echo e($time); ?>"
                                <?php echo e(old("working_days.$daySlug.start") == $time ? 'selected' : ''); ?>>
                                <?php echo e($time); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endfor; ?>
                </select>

                
                <select class="form-control form-control-sm w-auto end-time ml-2 select-user"
                        name="working_days[<?php echo e($daySlug); ?>][end]">
                    <?php for($h = 0; $h < 24; $h++): ?>
                        <?php $__currentLoopData = ['00', '30']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $time = str_pad($h, 2, '0', STR_PAD_LEFT) . ':' . $m; ?>
                            <option value="<?php echo e($time); ?>"
                                <?php echo e(old("working_days.$daySlug.end") == $time ? 'selected' : ''); ?>>
                                <?php echo e($time); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endfor; ?>
                </select>
            </div>

            
            <div class="d-flex align-items-center mt-3 w-100">
                <select class="form-control select-user service-select"
                        name="working_days[<?php echo e($daySlug); ?>][service_1][]"
                        multiple>
                    
                </select>
            </div>
        </div>
    </div>
</div>


<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Booking-Laravel/resources/views/admin/staff/partials/fields/add/working-day.blade.php ENDPATH**/ ?>