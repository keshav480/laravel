<div class="tab-pane fade show active" id="user-details" role="tabpanel">
        <?php echo $__env->make('admin.staff.partials.edit.avatar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Booking-Laravel/resources/views/admin/staff/partials/edit/user-details.blade.php ENDPATH**/ ?>