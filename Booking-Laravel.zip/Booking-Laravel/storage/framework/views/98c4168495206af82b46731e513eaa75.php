<?php $__env->startSection('content'); ?>
<div class="pcoded-main-container">
    <div class="pcoded-content">
        <!-- Page Header -->
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-12">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Edit Role</h5>
                        </div>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><i class="feather icon-home"></i></a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('roles.list')); ?>">Roles</a></li>
                            <li class="breadcrumb-item">Edit Role</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <!-- Form Card -->
        <div class="row">
            <div class="col-md-12 mx-auto">
                <div class="card">
                    <div class="card-body">
                        <form action="<?php echo e(route('roles.update', $role->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>

                            <!-- Role Name -->
                            <div class="form-group">
                                <label for="name" class="font-weight-bold">Role Name <span class="text-danger">*</span></label>
                                <input type="text" name="name" id="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('name', $role->name ?? '')); ?>" required>
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback d-block"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <!-- Permissions Table -->
                            <div class="form-group mt-4">
                                <label class="font-weight-bold">Permissions</label>
                                <div class="table-responsive border">
                                    <table class="table table-bordered mb-0">
                                        <thead class="thead-light">
                                            <tr>
                                                <th style="width: 60px;">
                                                    <div class="custom-control custom-checkbox">
                                                        <input type="checkbox" id="select-all-permissions" class="custom-control-input">
                                                        <label class="custom-control-label" for="select-all-permissions"></label>
                                                    </div>
                                                </th>
                                                <th>Name</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $roleGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupKey => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                            $oldPerms = old('permissions', $rolePermissions ?? []);
                                            $groupHasCheckedPerm = false;
                                            foreach ($group['roles'] as $perm) {
                                            if (in_array($perm, $oldPerms)) {
                                            $groupHasCheckedPerm = true;
                                            break;
                                            }
                                            }
                                            $groupSlug = $group['slug'];
                                            ?>
                                            <tr class="bg-light align-middle">
                                                <td class="text-center">
                                                    <div class="custom-control custom-checkbox">
                                                        <input type="checkbox" class="custom-control-input group-checkbox" data-group="<?php echo e($groupSlug); ?>" id="group_<?php echo e($groupKey); ?>" <?php echo e($groupHasCheckedPerm ? 'checked' : ''); ?>>
                                                        <label class="custom-control-label" for="group_<?php echo e($groupKey); ?>"></label>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="d-flex justify-content-between align-items-center w-100">
                                                        <label for="group_<?php echo e($groupKey); ?>" class="font-weight-bold mb-0">
                                                            <?php echo e($group['name']); ?>

                                                        </label>
                                                        <i class="feather icon-chevron-right toggle-icon" data-group="<?php echo e($groupSlug); ?>" style="cursor: pointer;"></i>
                                                    </div>
                                                </td>
                                            </tr>

                                            <?php $__currentLoopData = $group['roles']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $permissionId = Str::slug($permission); ?>
                                            <tr class="permission-row group-perms-<?php echo e($groupSlug); ?>" style="display: none;">
                                                <td class="text-center pl-4">
                                                    <div class="custom-control custom-checkbox">
                                                        <input type="checkbox" name="permissions[]" value="<?php echo e($permission); ?>" class="custom-control-input permission-checkbox group-<?php echo e($groupSlug); ?>" id="perm_<?php echo e($permissionId); ?>" <?php echo e(in_array($permission, $oldPerms) ? 'checked' : ''); ?>>
                                                        <label class="custom-control-label" for="perm_<?php echo e($permissionId); ?>"></label>
                                                    </div>
                                                </td>
                                                <td>
                                                    <label for="perm_<?php echo e($permissionId); ?>" class="mb-0">
                                                        <?php echo e(ucfirst($permission)); ?>

                                                    </label>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                                <?php $__errorArgs = ['permissions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <!-- Status -->
                            <div class="form-group mt-3">
                                <label for="status" class="form-label d-block font-weight-bold">Status</label>
                                <select name="status" id="status" class="form-control select-user">
                                    <option value="<?php echo e(config('constants.status.active')); ?>"
                                        <?php echo e(old('status', $role->status) == config('constants.status.active') ? 'selected' : ''); ?>>
                                        Active
                                    </option>
                                    <option value="<?php echo e(config('constants.status.inactive')); ?>"
                                        <?php echo e(old('status', $role->status) == config('constants.status.inactive') ? 'selected' : ''); ?>>
                                        Inactive
                                    </option>
                                </select>
                                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <!-- Submit Buttons -->
                            <div class="form-group mt-4">
                                <button type="submit" class="btn btn-primary">Update</button>
                                <a href="<?php echo e(route('roles.list')); ?>" class="btn btn-secondary">Back</a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/Booking-Laravel/resources/views/admin/role/edit.blade.php ENDPATH**/ ?>